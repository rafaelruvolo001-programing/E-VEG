E-veg - site da loja de produtos veganos

Arquivos:
- paginas .html: uma para cada pagina do site
- css/style.css: visual do site
- js/script.js: carrinho, formularios e calculo do orcamento

Para ver o site, abra o index.html no navegador.
